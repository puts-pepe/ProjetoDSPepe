﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProjetoDSJoaoP
{
    public partial class frmUsuario : Form
    {
        public frmUsuario()
        {
            InitializeComponent();
        }

        private void frmUsuario_Load(object sender, EventArgs e)
        {
            txtLogin.Enabled = false;
            txtSenha.Enabled = false;
            btnProx.Enabled = false;
        }

        private void btnProx_Click(object sender, EventArgs e)
        {
            MySqlConnection conn = new MySqlConnection("server=localhost;database=bdclinicapsiquiatrica;uid=root;pwd=''");
            MySqlCommand comando = new MySqlCommand();
            comando.Connection = conn;
            comando.CommandText = ("insert into usuario (login, senha) values (@Login,@Senha)");
            comando.Parameters.AddWithValue("@Login", txtLogin.Text);
            comando.Parameters.AddWithValue("@Senha", txtSenha.Text);
            conn.Open();
            comando.ExecuteNonQuery();
            MessageBox.Show("usuário cadastrado com sucesso");
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            txtLogin.Enabled = true;
            txtSenha.Enabled = true;
            btnProx.Enabled = true;
            txtLogin.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            frmMenu menu = new frmMenu();
            menu.Show();
            this.Hide();
        }
    }
}

