﻿
namespace ProjetoDSJoaoP
{
    partial class frmMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnProxCadUsu = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnProxCadCli = new System.Windows.Forms.Button();
            this.btnConsuCli = new System.Windows.Forms.Button();
            this.btnAltSenha = new System.Windows.Forms.Button();
            this.btnLogin = new System.Windows.Forms.Button();
            this.btnUsu = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnProxCadUsu
            // 
            this.btnProxCadUsu.BackColor = System.Drawing.SystemColors.ControlText;
            this.btnProxCadUsu.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProxCadUsu.ForeColor = System.Drawing.SystemColors.Control;
            this.btnProxCadUsu.Location = new System.Drawing.Point(552, 178);
            this.btnProxCadUsu.Name = "btnProxCadUsu";
            this.btnProxCadUsu.Size = new System.Drawing.Size(252, 69);
            this.btnProxCadUsu.TabIndex = 1;
            this.btnProxCadUsu.Text = "PRÓXIMO";
            this.btnProxCadUsu.UseVisualStyleBackColor = false;
            this.btnProxCadUsu.Click += new System.EventHandler(this.btnProxCadUsu_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ProjetoDSJoaoP.Properties.Resources.mENU;
            this.pictureBox1.Location = new System.Drawing.Point(-1, 1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1246, 821);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // btnProxCadCli
            // 
            this.btnProxCadCli.BackColor = System.Drawing.SystemColors.ControlText;
            this.btnProxCadCli.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProxCadCli.ForeColor = System.Drawing.SystemColors.Control;
            this.btnProxCadCli.Location = new System.Drawing.Point(552, 288);
            this.btnProxCadCli.Name = "btnProxCadCli";
            this.btnProxCadCli.Size = new System.Drawing.Size(252, 68);
            this.btnProxCadCli.TabIndex = 2;
            this.btnProxCadCli.Text = "PRÓXIMO";
            this.btnProxCadCli.UseVisualStyleBackColor = false;
            this.btnProxCadCli.Click += new System.EventHandler(this.btnProxCadCli_Click);
            // 
            // btnConsuCli
            // 
            this.btnConsuCli.BackColor = System.Drawing.SystemColors.ControlText;
            this.btnConsuCli.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConsuCli.ForeColor = System.Drawing.SystemColors.Control;
            this.btnConsuCli.Location = new System.Drawing.Point(552, 391);
            this.btnConsuCli.Name = "btnConsuCli";
            this.btnConsuCli.Size = new System.Drawing.Size(252, 68);
            this.btnConsuCli.TabIndex = 3;
            this.btnConsuCli.Text = "PRÓXIMO";
            this.btnConsuCli.UseVisualStyleBackColor = false;
            // 
            // btnAltSenha
            // 
            this.btnAltSenha.BackColor = System.Drawing.SystemColors.ControlText;
            this.btnAltSenha.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAltSenha.ForeColor = System.Drawing.SystemColors.Control;
            this.btnAltSenha.Location = new System.Drawing.Point(876, 179);
            this.btnAltSenha.Name = "btnAltSenha";
            this.btnAltSenha.Size = new System.Drawing.Size(252, 68);
            this.btnAltSenha.TabIndex = 4;
            this.btnAltSenha.Text = "PRÓXIMO";
            this.btnAltSenha.UseVisualStyleBackColor = false;
            // 
            // btnLogin
            // 
            this.btnLogin.BackColor = System.Drawing.SystemColors.ControlText;
            this.btnLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogin.ForeColor = System.Drawing.SystemColors.Control;
            this.btnLogin.Location = new System.Drawing.Point(876, 288);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(252, 68);
            this.btnLogin.TabIndex = 5;
            this.btnLogin.Text = "PRÓXIMO";
            this.btnLogin.UseVisualStyleBackColor = false;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // btnUsu
            // 
            this.btnUsu.BackColor = System.Drawing.SystemColors.ControlText;
            this.btnUsu.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUsu.ForeColor = System.Drawing.SystemColors.Control;
            this.btnUsu.Location = new System.Drawing.Point(876, 391);
            this.btnUsu.Name = "btnUsu";
            this.btnUsu.Size = new System.Drawing.Size(252, 68);
            this.btnUsu.TabIndex = 6;
            this.btnUsu.Text = "PRÓXIMO";
            this.btnUsu.UseVisualStyleBackColor = false;
            // 
            // btnSair
            // 
            this.btnSair.BackColor = System.Drawing.SystemColors.ControlText;
            this.btnSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSair.ForeColor = System.Drawing.SystemColors.Control;
            this.btnSair.Location = new System.Drawing.Point(699, 512);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(297, 47);
            this.btnSair.TabIndex = 7;
            this.btnSair.Text = "SAIR";
            this.btnSair.UseVisualStyleBackColor = false;
            this.btnSair.Click += new System.EventHandler(this.button6_Click);
            // 
            // frmMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1245, 823);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnUsu);
            this.Controls.Add(this.btnLogin);
            this.Controls.Add(this.btnAltSenha);
            this.Controls.Add(this.btnConsuCli);
            this.Controls.Add(this.btnProxCadCli);
            this.Controls.Add(this.btnProxCadUsu);
            this.Controls.Add(this.pictureBox1);
            this.MaximizeBox = false;
            this.Name = "frmMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnProxCadUsu;
        private System.Windows.Forms.Button btnProxCadCli;
        private System.Windows.Forms.Button btnConsuCli;
        private System.Windows.Forms.Button btnAltSenha;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Button btnUsu;
        private System.Windows.Forms.Button btnSair;
    }
}