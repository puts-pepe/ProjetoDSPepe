﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProjetoDSJoaoP
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void txtSenha_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnProx_Click(object sender, EventArgs e)
        {
            String login ;
            MySqlDataReader reg = null;
            MySqlConnection conn = new MySqlConnection("server=localhost;database=bdclinicapsiquiatrica;uid=root;pwd=''");
            MySqlCommand comando = new MySqlCommand();
            comando.Connection = conn;
            comando.CommandText = "select * from usuario where login = @login and senha = @senha";
            comando.Parameters.AddWithValue("@login", txtLogin.Text);
            comando.Parameters.AddWithValue("@senha", txtSenha.Text);
            conn.Open() ;
            reg = comando.ExecuteReader();
            if (reg.Read ())
            {
                login = reg ["login"].ToString() ;
                MessageBox.Show("Usuário Logado!") ;

                frmMenu menu = new frmMenu() ;
                menu.Show() ;
                this.Hide() ;
            }
            else
            {
                MessageBox.Show("Usuário não Logado!") ;
                txtLogin.Text = " " ;
                txtSenha.Text = " " ;
                txtLogin.Focus(); 
            }

        }

        private void login_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            frmMenu menu = new frmMenu();
            menu.Show();
            this.Hide();
        }
    }
}
