﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProjetoDSJoaoP
{
    public partial class cadastroCliente : Form
    {
        public cadastroCliente()
        {
            InitializeComponent();
        }

        private void btnProx_Click(object sender, EventArgs e)
        {
            MySqlConnection conn = new MySqlConnection("server=localhost;database=bdclinicapsiquiatrica;uid=root;pwd=''");
            MySqlCommand comando = new MySqlCommand();
            comando.Connection = conn;
            comando.CommandText = ("insert into paciente (cpf,nome,idade,data_nascimento,email,telefone,cidade,estado) values (@cpf,@nome,@idade,@data_nascimento,@email,@telefone,@cidade,@estado)");
            comando.Parameters.AddWithValue("@cpf", txtcpf.Text);
            comando.Parameters.AddWithValue("@nome", txtNome.Text);
            comando.Parameters.AddWithValue("@idade", txtidade.Text);
            comando.Parameters.AddWithValue("@data_nascimento", txtData.Text);
            comando.Parameters.AddWithValue("@email", txtemail.Text);
            comando.Parameters.AddWithValue("@telefone", txtTelefone.Text);
            comando.Parameters.AddWithValue("@cidade", txtCidade.Text);
            comando.Parameters.AddWithValue("@estado", txtEstado.Text);
            conn.Open();
            comando.ExecuteNonQuery();
            MessageBox.Show("cliente cadastrado com sucesso");
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            txtcpf.Enabled = true;
            txtNome.Enabled = true;
            txtidade.Enabled = true;
            txtData.Enabled = true;
            txtemail.Enabled = true;
            txtTelefone.Enabled = true;
            txtCidade.Enabled = true;
            txtEstado.Enabled = true;
            btnSave.Enabled = true;
            txtcpf.Focus();
        }

        private void cadastroCliente_Load(object sender, EventArgs e)
        {
            txtcpf.Enabled = false;
            txtNome.Enabled = false;
            txtidade.Enabled = false;
            txtData.Enabled = false;
            txtemail.Enabled = false;
            txtTelefone.Enabled = false;
            txtCidade.Enabled = false;
            txtEstado.Enabled = false;
            btnSave.Enabled = false;
            btnConsulta.Enabled = false;
        }

        private void txtcpf_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            frmMenu menu = new frmMenu();
            menu.Show();
            this.Hide();
        }
    }
}
